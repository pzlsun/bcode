package publicresourcewrite.code.pojo;
import java.util.Date;
import java.util.Map;
import java.util.List;
import java.util.UUID;
import baselib.baseclass.BasePojo;
//增加字段注释

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.wordnik.swagger.annotations.ApiModelProperty;
///////////////////////////////////////////////////////////
// ObjectID : B4DDFFAE-6B83-40A8-9936-1B0AD744942B
//我的导师
//

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class MyTutor  extends BasePojo implements java.io.Serializable {
  
    @ApiModelProperty(value = "主键列表（公共字段）")
    private List<Object> keylist;
		
	 
	 	public List<Object> getKeylist() {
			return keylist;
		}
		public void setKeylist(List<Object> keylist) {
			this.keylist = keylist;
		}
    
    
	protected static final long serialVersionUID = -5657696043382912397l;
	 	/*
		 0.ID
	 	 备注:
		*/
	 	@ApiModelProperty(value = "ID")
	 	private Integer iD ;
	 	public Integer getID ()
	 	{
	 		return this.iD;
	 	}
	 	public void setID (Integer value)
	 	{
	 		this.iD	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 1.导师ID
	 	 备注:
		*/
	 	@ApiModelProperty(value = "导师ID")
	 	private Integer tutorID ;
	 	public Integer getTutorID ()
	 	{
	 		return this.tutorID;
	 	}
	 	public void setTutorID (Integer value)
	 	{
	 		this.tutorID	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 2.门徒ID
	 	 备注:
		*/
	 	@ApiModelProperty(value = "门徒ID")
	 	private Integer discipleID ;
	 	public Integer getDiscipleID ()
	 	{
	 		return this.discipleID;
	 	}
	 	public void setDiscipleID (Integer value)
	 	{
	 		this.discipleID	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 3.时间
	 	 备注:
		*/
	 	@ApiModelProperty(value = "时间")
	 	private Date occurrenceTime ;
	 	public Date getOccurrenceTime ()
	 	{
	 		return this.occurrenceTime;
	 	}
	 	public void setOccurrenceTime (Date value)
	 	{
	 		this.occurrenceTime	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 4.状态
	 	 备注:
		*/
	 	@ApiModelProperty(value = "状态")
	 	private Integer status ;
	 	public Integer getStatus ()
	 	{
	 		return this.status;
	 	}
	 	public void setStatus (Integer value)
	 	{
	 		this.status	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	public void setSession(Map map) {
		// TODO Auto-generated method stub
	}
}
 
 
 
 

 
		 

 


