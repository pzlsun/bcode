package publicresourcewrite.code.pojo;
import java.util.Date;
import java.util.Map;
import java.util.List;
import java.util.UUID;
import baselib.baseclass.BasePojo;
//增加字段注释

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.wordnik.swagger.annotations.ApiModelProperty;
///////////////////////////////////////////////////////////
// ObjectID : 02ECDB8F-B5F9-4AA9-8326-ED31F7D98076
//导师团
//

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class DoctorTeam  extends BasePojo implements java.io.Serializable {
  
    @ApiModelProperty(value = "主键列表（公共字段）")
    private List<Object> keylist;
		
	 
	 	public List<Object> getKeylist() {
			return keylist;
		}
		public void setKeylist(List<Object> keylist) {
			this.keylist = keylist;
		}
    
    
	protected static final long serialVersionUID = -4802098959308499623l;
	 	/*
		 0.ID
	 	 备注:
		*/
	 	@ApiModelProperty(value = "ID")
	 	private Integer iD ;
	 	public Integer getID ()
	 	{
	 		return this.iD;
	 	}
	 	public void setID (Integer value)
	 	{
	 		this.iD	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 1.专家组名称
	 	 备注:
		*/
	 	@ApiModelProperty(value = "专家组名称")
	 	private String teamName ;
	 	public String getTeamName ()
	 	{
	 		return this.teamName;
	 	}
	 	public void setTeamName (String value)
	 	{
	 		this.teamName	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 2.专家组LOGO
	 	 备注:
		*/
	 	@ApiModelProperty(value = "专家组LOGO")
	 	private String teamLogo ;
	 	public String getTeamLogo ()
	 	{
	 		return this.teamLogo;
	 	}
	 	public void setTeamLogo (String value)
	 	{
	 		this.teamLogo	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 3.大图
	 	 备注:
		*/
	 	@ApiModelProperty(value = "大图")
	 	private String teamImageUrl ;
	 	public String getTeamImageUrl ()
	 	{
	 		return this.teamImageUrl;
	 	}
	 	public void setTeamImageUrl (String value)
	 	{
	 		this.teamImageUrl	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 4.专家组简介
	 	 备注:
		*/
	 	@ApiModelProperty(value = "专家组简介")
	 	private String teamSummary ;
	 	public String getTeamSummary ()
	 	{
	 		return this.teamSummary;
	 	}
	 	public void setTeamSummary (String value)
	 	{
	 		this.teamSummary	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 5.专家组摘要
	 	 备注:
		*/
	 	@ApiModelProperty(value = "专家组摘要")
	 	private String teamDescription ;
	 	public String getTeamDescription ()
	 	{
	 		return this.teamDescription;
	 	}
	 	public void setTeamDescription (String value)
	 	{
	 		this.teamDescription	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 6.医院key
	 	 备注:
		*/
	 	@ApiModelProperty(value = "医院key")
	 	private String hospitalKey ;
	 	public String getHospitalKey ()
	 	{
	 		return this.hospitalKey;
	 	}
	 	public void setHospitalKey (String value)
	 	{
	 		this.hospitalKey	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 7.医院名称
	 	 备注:
		*/
	 	@ApiModelProperty(value = "医院名称")
	 	private String hospitalName ;
	 	public String getHospitalName ()
	 	{
	 		return this.hospitalName;
	 	}
	 	public void setHospitalName (String value)
	 	{
	 		this.hospitalName	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 8.导师人数
	 	 备注:
		*/
	 	@ApiModelProperty(value = "导师人数")
	 	private Integer teacherCount ;
	 	public Integer getTeacherCount ()
	 	{
	 		return this.teacherCount;
	 	}
	 	public void setTeacherCount (Integer value)
	 	{
	 		this.teacherCount	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 9.学生人数
	 	 备注:
		*/
	 	@ApiModelProperty(value = "学生人数")
	 	private Integer studentsCount ;
	 	public Integer getStudentsCount ()
	 	{
	 		return this.studentsCount;
	 	}
	 	public void setStudentsCount (Integer value)
	 	{
	 		this.studentsCount	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 10.组长ID
	 	 备注:
		*/
	 	@ApiModelProperty(value = "组长ID")
	 	private Integer leader ;
	 	public Integer getLeader ()
	 	{
	 		return this.leader;
	 	}
	 	public void setLeader (Integer value)
	 	{
	 		this.leader	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 11.组长姓名
	 	 备注:
		*/
	 	@ApiModelProperty(value = "组长姓名")
	 	private String leaderName ;
	 	public String getLeaderName ()
	 	{
	 		return this.leaderName;
	 	}
	 	public void setLeaderName (String value)
	 	{
	 		this.leaderName	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 12.组长头像
	 	 备注:
		*/
	 	@ApiModelProperty(value = "组长头像")
	 	private String leaderHeaderImg ;
	 	public String getLeaderHeaderImg ()
	 	{
	 		return this.leaderHeaderImg;
	 	}
	 	public void setLeaderHeaderImg (String value)
	 	{
	 		this.leaderHeaderImg	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 13.创建时间
	 	 备注:
		*/
	 	@ApiModelProperty(value = "创建时间")
	 	private Date createTime ;
	 	public Date getCreateTime ()
	 	{
	 		return this.createTime;
	 	}
	 	public void setCreateTime (Date value)
	 	{
	 		this.createTime	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 14.审核状态
	 	 备注:
		*/
	 	@ApiModelProperty(value = "审核状态")
	 	private Integer checkStatus ;
	 	public Integer getCheckStatus ()
	 	{
	 		return this.checkStatus;
	 	}
	 	public void setCheckStatus (Integer value)
	 	{
	 		this.checkStatus	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 15.状态
	 	 备注:
		*/
	 	@ApiModelProperty(value = "状态")
	 	private Integer status ;
	 	public Integer getStatus ()
	 	{
	 		return this.status;
	 	}
	 	public void setStatus (Integer value)
	 	{
	 		this.status	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 16.组长信息
	 	 备注:
		*/
	 	@ApiModelProperty(value = "组长信息")
	 	private String leaderInfo ;
	 	public String getLeaderInfo ()
	 	{
	 		return this.leaderInfo;
	 	}
	 	public void setLeaderInfo (String value)
	 	{
	 		this.leaderInfo	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 17.是否接收转诊
	 	 备注:
		*/
	 	@ApiModelProperty(value = "是否接收转诊")
	 	private Boolean isAcceptReferral ;
	 	public Boolean getIsAcceptReferral ()
	 	{
	 		return this.isAcceptReferral;
	 	}
	 	public void setIsAcceptReferral (Boolean value)
	 	{
	 		this.isAcceptReferral	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 18.是否推荐
	 	 备注:
		*/
	 	@ApiModelProperty(value = "是否推荐")
	 	private Boolean isRecommend ;
	 	public Boolean getIsRecommend ()
	 	{
	 		return this.isRecommend;
	 	}
	 	public void setIsRecommend (Boolean value)
	 	{
	 		this.isRecommend	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 19.推荐logo
	 	 备注:
		*/
	 	@ApiModelProperty(value = "推荐logo")
	 	private String recommendLogo ;
	 	public String getRecommendLogo ()
	 	{
	 		return this.recommendLogo;
	 	}
	 	public void setRecommendLogo (String value)
	 	{
	 		this.recommendLogo	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 20.推荐时间
	 	 备注:
		*/
	 	@ApiModelProperty(value = "推荐时间")
	 	private Date recommendTime ;
	 	public Date getRecommendTime ()
	 	{
	 		return this.recommendTime;
	 	}
	 	public void setRecommendTime (Date value)
	 	{
	 		this.recommendTime	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 21.互动指数
	 	 备注:
		*/
	 	@ApiModelProperty(value = "互动指数")
	 	private Double interactiveIndex ;
	 	public Double getInteractiveIndex ()
	 	{
	 		return this.interactiveIndex;
	 	}
	 	public void setInteractiveIndex (Double value)
	 	{
	 		this.interactiveIndex	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 22.最后更新时间
	 	 备注:
		*/
	 	@ApiModelProperty(value = "最后更新时间")
	 	private Date lastUpdateTime ;
	 	public Date getLastUpdateTime ()
	 	{
	 		return this.lastUpdateTime;
	 	}
	 	public void setLastUpdateTime (Date value)
	 	{
	 		this.lastUpdateTime	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	public void setSession(Map map) {
		// TODO Auto-generated method stub
	}
}
 
 
 
 

 
		 

 


