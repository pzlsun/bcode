package publicresourcewrite.code.pojo;
import java.util.Date;
import java.util.Map;
import java.util.List;
import java.util.UUID;
import baselib.baseclass.BasePojo;
//增加字段注释

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.wordnik.swagger.annotations.ApiModelProperty;
///////////////////////////////////////////////////////////
// ObjectID : D2FAF3FD-C79B-452E-B6B8-8FD135DADF00
//用户_推荐
//

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class User_Behavior_Record  extends BasePojo implements java.io.Serializable {
  
    @ApiModelProperty(value = "主键列表（公共字段）")
    private List<Object> keylist;
		
	 
	 	public List<Object> getKeylist() {
			return keylist;
		}
		public void setKeylist(List<Object> keylist) {
			this.keylist = keylist;
		}
    
    
	protected static final long serialVersionUID = -7533102095807730256l;
	 	/*
		 0.ID
	 	 备注:
		*/
	 	@ApiModelProperty(value = "ID")
	 	private Long iD ;
	 	public Long getID ()
	 	{
	 		return this.iD;
	 	}
	 	public void setID (Long value)
	 	{
	 		this.iD	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 1.频道Key
	 	 备注:
		*/
	 	@ApiModelProperty(value = "频道Key")
	 	private String channelKey ;
	 	public String getChannelKey ()
	 	{
	 		return this.channelKey;
	 	}
	 	public void setChannelKey (String value)
	 	{
	 		this.channelKey	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 2.用户ID
	 	 备注:
		*/
	 	@ApiModelProperty(value = "用户ID")
	 	private Integer userID ;
	 	public Integer getUserID ()
	 	{
	 		return this.userID;
	 	}
	 	public void setUserID (Integer value)
	 	{
	 		this.userID	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 3.标题预览
	 	 备注:
		*/
	 	@ApiModelProperty(value = "标题预览")
	 	private String title ;
	 	public String getTitle ()
	 	{
	 		return this.title;
	 	}
	 	public void setTitle (String value)
	 	{
	 		this.title	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 4.副标题
	 	 备注:
		*/
	 	@ApiModelProperty(value = "副标题")
	 	private String secondTitle ;
	 	public String getSecondTitle ()
	 	{
	 		return this.secondTitle;
	 	}
	 	public void setSecondTitle (String value)
	 	{
	 		this.secondTitle	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 5.摘要
	 	 备注:
		*/
	 	@ApiModelProperty(value = "摘要")
	 	private String summary ;
	 	public String getSummary ()
	 	{
	 		return this.summary;
	 	}
	 	public void setSummary (String value)
	 	{
	 		this.summary	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 6.图片预览
	 	 备注:
		*/
	 	@ApiModelProperty(value = "图片预览")
	 	private String imageUrl ;
	 	public String getImageUrl ()
	 	{
	 		return this.imageUrl;
	 	}
	 	public void setImageUrl (String value)
	 	{
	 		this.imageUrl	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 7.Url地址
	 	 备注:
		*/
	 	@ApiModelProperty(value = "Url地址")
	 	private String url ;
	 	public String getUrl ()
	 	{
	 		return this.url;
	 	}
	 	public void setUrl (String value)
	 	{
	 		this.url	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 8.来源
	 	 备注:
		*/
	 	@ApiModelProperty(value = "来源")
	 	private String source ;
	 	public String getSource ()
	 	{
	 		return this.source;
	 	}
	 	public void setSource (String value)
	 	{
	 		this.source	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 9.Item类型
	 	 备注:
		*/
	 	@ApiModelProperty(value = "Item类型")
	 	private String itemType ;
	 	public String getItemType ()
	 	{
	 		return this.itemType;
	 	}
	 	public void setItemType (String value)
	 	{
	 		this.itemType	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 10.数据项
	 	 备注:
		*/
	 	@ApiModelProperty(value = "数据项")
	 	private Long itemID ;
	 	public Long getItemID ()
	 	{
	 		return this.itemID;
	 	}
	 	public void setItemID (Long value)
	 	{
	 		this.itemID	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 11.行为
	 	 备注:
		*/
	 	@ApiModelProperty(value = "行为")
	 	private String behaviorType ;
	 	public String getBehaviorType ()
	 	{
	 		return this.behaviorType;
	 	}
	 	public void setBehaviorType (String value)
	 	{
	 		this.behaviorType	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 12.创建时间
	 	 备注:
		*/
	 	@ApiModelProperty(value = "创建时间")
	 	private Date createTime ;
	 	public Date getCreateTime ()
	 	{
	 		return this.createTime;
	 	}
	 	public void setCreateTime (Date value)
	 	{
	 		this.createTime	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 13.Json标签
	 	 备注:
		*/
	 	@ApiModelProperty(value = "Json标签")
	 	private String jsonTag ;
	 	public String getJsonTag ()
	 	{
	 		return this.jsonTag;
	 	}
	 	public void setJsonTag (String value)
	 	{
	 		this.jsonTag	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 14.用户分类标签
	 	 备注:
		*/
	 	@ApiModelProperty(value = "用户分类标签")
	 	private String userDefineClassTag ;
	 	public String getUserDefineClassTag ()
	 	{
	 		return this.userDefineClassTag;
	 	}
	 	public void setUserDefineClassTag (String value)
	 	{
	 		this.userDefineClassTag	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 15.状态
	 	 备注:
		*/
	 	@ApiModelProperty(value = "状态")
	 	private Integer status ;
	 	public Integer getStatus ()
	 	{
	 		return this.status;
	 	}
	 	public void setStatus (Integer value)
	 	{
	 		this.status	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	public void setSession(Map map) {
		// TODO Auto-generated method stub
	}
}
 
 
 
 

 
		 

 


