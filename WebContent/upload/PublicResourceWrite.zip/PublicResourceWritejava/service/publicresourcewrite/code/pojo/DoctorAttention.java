package publicresourcewrite.code.pojo;
import java.util.Date;
import java.util.Map;
import java.util.List;
import java.util.UUID;
import baselib.baseclass.BasePojo;
//增加字段注释

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.wordnik.swagger.annotations.ApiModelProperty;
///////////////////////////////////////////////////////////
// ObjectID : F5FE779C-7AE4-4C30-8D9C-72DDB6D3F96C
//关注关系
//

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class DoctorAttention  extends BasePojo implements java.io.Serializable {
  
    @ApiModelProperty(value = "主键列表（公共字段）")
    private List<Object> keylist;
		
	 
	 	public List<Object> getKeylist() {
			return keylist;
		}
		public void setKeylist(List<Object> keylist) {
			this.keylist = keylist;
		}
    
    
	protected static final long serialVersionUID = -5242956631273238777l;
	 	/*
		 0.ID
	 	 备注:
		*/
	 	@ApiModelProperty(value = "ID")
	 	private Integer iD ;
	 	public Integer getID ()
	 	{
	 		return this.iD;
	 	}
	 	public void setID (Integer value)
	 	{
	 		this.iD	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 1.医生ID
	 	 备注:
		*/
	 	@ApiModelProperty(value = "医生ID")
	 	private Integer userID ;
	 	public Integer getUserID ()
	 	{
	 		return this.userID;
	 	}
	 	public void setUserID (Integer value)
	 	{
	 		this.userID	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 2.被关注医生ID
	 	 备注:
		*/
	 	@ApiModelProperty(value = "被关注医生ID")
	 	private Integer followedUserID ;
	 	public Integer getFollowedUserID ()
	 	{
	 		return this.followedUserID;
	 	}
	 	public void setFollowedUserID (Integer value)
	 	{
	 		this.followedUserID	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 3.创建时间
	 	 备注:
		*/
	 	@ApiModelProperty(value = "创建时间")
	 	private Date createTime ;
	 	public Date getCreateTime ()
	 	{
	 		return this.createTime;
	 	}
	 	public void setCreateTime (Date value)
	 	{
	 		this.createTime	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 4.关系
	 	 备注:
		*/
	 	@ApiModelProperty(value = "关系")
	 	private String relation ;
	 	public String getRelation ()
	 	{
	 		return this.relation;
	 	}
	 	public void setRelation (String value)
	 	{
	 		this.relation	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 5.状态
	 	 备注:
		*/
	 	@ApiModelProperty(value = "状态")
	 	private Integer status ;
	 	public Integer getStatus ()
	 	{
	 		return this.status;
	 	}
	 	public void setStatus (Integer value)
	 	{
	 		this.status	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	public void setSession(Map map) {
		// TODO Auto-generated method stub
	}
}
 
 
 
 

 
		 

 


