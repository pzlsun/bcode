package publicresourcewrite.code.pojo;
import java.util.Date;
import java.util.Map;
import java.util.List;
import java.util.UUID;
import baselib.baseclass.BasePojo;
//增加字段注释

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.wordnik.swagger.annotations.ApiModelProperty;
///////////////////////////////////////////////////////////
// ObjectID : 19F9AAB7-5491-4FC0-9568-A74B53888304
//首页动态
//

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class HomeMessage  extends BasePojo implements java.io.Serializable {
  
    @ApiModelProperty(value = "主键列表（公共字段）")
    private List<Object> keylist;
		
	 
	 	public List<Object> getKeylist() {
			return keylist;
		}
		public void setKeylist(List<Object> keylist) {
			this.keylist = keylist;
		}
    
    
	protected static final long serialVersionUID = 5976402085168728584l;
	 	/*
		 0.ID
	 	 备注:
		*/
	 	@ApiModelProperty(value = "ID")
	 	private Integer iD ;
	 	public Integer getID ()
	 	{
	 		return this.iD;
	 	}
	 	public void setID (Integer value)
	 	{
	 		this.iD	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 1.医生ID
	 	 备注:
		*/
	 	@ApiModelProperty(value = "医生ID")
	 	private Integer doctorID ;
	 	public Integer getDoctorID ()
	 	{
	 		return this.doctorID;
	 	}
	 	public void setDoctorID (Integer value)
	 	{
	 		this.doctorID	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 2.医生姓名
	 	 备注:
		*/
	 	@ApiModelProperty(value = "医生姓名")
	 	private String doctorName ;
	 	public String getDoctorName ()
	 	{
	 		return this.doctorName;
	 	}
	 	public void setDoctorName (String value)
	 	{
	 		this.doctorName	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 3.是否有工作室
	 	 备注:
		*/
	 	@ApiModelProperty(value = "是否有工作室")
	 	private Boolean hasTeam ;
	 	public Boolean getHasTeam ()
	 	{
	 		return this.hasTeam;
	 	}
	 	public void setHasTeam (Boolean value)
	 	{
	 		this.hasTeam	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 4.头像
	 	 备注:
		*/
	 	@ApiModelProperty(value = "头像")
	 	private String headImg ;
	 	public String getHeadImg ()
	 	{
	 		return this.headImg;
	 	}
	 	public void setHeadImg (String value)
	 	{
	 		this.headImg	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 5.动态内容
	 	 备注:
		*/
	 	@ApiModelProperty(value = "动态内容")
	 	private String content ;
	 	public String getContent ()
	 	{
	 		return this.content;
	 	}
	 	public void setContent (String value)
	 	{
	 		this.content	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 6.状态
	 	 备注:
		*/
	 	@ApiModelProperty(value = "状态")
	 	private Integer status ;
	 	public Integer getStatus ()
	 	{
	 		return this.status;
	 	}
	 	public void setStatus (Integer value)
	 	{
	 		this.status	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 7.显示状态
	 	 备注:
		*/
	 	@ApiModelProperty(value = "显示状态")
	 	private String showStatus ;
	 	public String getShowStatus ()
	 	{
	 		return this.showStatus;
	 	}
	 	public void setShowStatus (String value)
	 	{
	 		this.showStatus	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 8.导师头像
	 	 备注:
		*/
	 	@ApiModelProperty(value = "导师头像")
	 	private String tutorHeadImg ;
	 	public String getTutorHeadImg ()
	 	{
	 		return this.tutorHeadImg;
	 	}
	 	public void setTutorHeadImg (String value)
	 	{
	 		this.tutorHeadImg	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 9.导师ID
	 	 备注:
		*/
	 	@ApiModelProperty(value = "导师ID")
	 	private Integer tutorID ;
	 	public Integer getTutorID ()
	 	{
	 		return this.tutorID;
	 	}
	 	public void setTutorID (Integer value)
	 	{
	 		this.tutorID	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 10.创建时间
	 	 备注:
		*/
	 	@ApiModelProperty(value = "创建时间")
	 	private Date createTime ;
	 	public Date getCreateTime ()
	 	{
	 		return this.createTime;
	 	}
	 	public void setCreateTime (Date value)
	 	{
	 		this.createTime	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 11.导师姓名
	 	 备注:
		*/
	 	@ApiModelProperty(value = "导师姓名")
	 	private String tutorName ;
	 	public String getTutorName ()
	 	{
	 		return this.tutorName;
	 	}
	 	public void setTutorName (String value)
	 	{
	 		this.tutorName	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	public void setSession(Map map) {
		// TODO Auto-generated method stub
	}
}
 
 
 
 

 
		 

 


