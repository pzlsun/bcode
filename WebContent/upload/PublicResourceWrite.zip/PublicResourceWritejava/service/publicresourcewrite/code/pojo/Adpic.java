package publicresourcewrite.code.pojo;
import java.util.Date;
import java.util.Map;
import java.util.List;
import java.util.UUID;
import baselib.baseclass.BasePojo;
//增加字段注释

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.wordnik.swagger.annotations.ApiModelProperty;
///////////////////////////////////////////////////////////
// ObjectID : 297ACA20-B943-45EB-BA4E-0BD5F8748740
//banner壁纸
//

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class Adpic  extends BasePojo implements java.io.Serializable {
  
    @ApiModelProperty(value = "主键列表（公共字段）")
    private List<Object> keylist;
		
	 
	 	public List<Object> getKeylist() {
			return keylist;
		}
		public void setKeylist(List<Object> keylist) {
			this.keylist = keylist;
		}
    
    
	protected static final long serialVersionUID = 2715853340787095574l;
	 	/*
		 0.ID
	 	 备注:
		*/
	 	@ApiModelProperty(value = "ID")
	 	private Integer iD ;
	 	public Integer getID ()
	 	{
	 		return this.iD;
	 	}
	 	public void setID (Integer value)
	 	{
	 		this.iD	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 1.图片地址
	 	 备注:
		*/
	 	@ApiModelProperty(value = "图片地址")
	 	private String adPicUrl ;
	 	public String getAdPicUrl ()
	 	{
	 		return this.adPicUrl;
	 	}
	 	public void setAdPicUrl (String value)
	 	{
	 		this.adPicUrl	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 2.标题
	 	 备注:
		*/
	 	@ApiModelProperty(value = "标题")
	 	private String adTitle ;
	 	public String getAdTitle ()
	 	{
	 		return this.adTitle;
	 	}
	 	public void setAdTitle (String value)
	 	{
	 		this.adTitle	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 3.类型
	 	 备注:
		*/
	 	@ApiModelProperty(value = "类型")
	 	private String type ;
	 	public String getType ()
	 	{
	 		return this.type;
	 	}
	 	public void setType (String value)
	 	{
	 		this.type	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 4.状态
	 	 备注:
		*/
	 	@ApiModelProperty(value = "状态")
	 	private Integer status ;
	 	public Integer getStatus ()
	 	{
	 		return this.status;
	 	}
	 	public void setStatus (Integer value)
	 	{
	 		this.status	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 5.跳转参数
	 	 备注:
		*/
	 	@ApiModelProperty(value = "跳转参数")
	 	private String intentParam ;
	 	public String getIntentParam ()
	 	{
	 		return this.intentParam;
	 	}
	 	public void setIntentParam (String value)
	 	{
	 		this.intentParam	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 6.跳转类型
	 	 备注:
		*/
	 	@ApiModelProperty(value = "跳转类型")
	 	private String intentType ;
	 	public String getIntentType ()
	 	{
	 		return this.intentType;
	 	}
	 	public void setIntentType (String value)
	 	{
	 		this.intentType	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 7.排序
	 	 备注:
		*/
	 	@ApiModelProperty(value = "排序")
	 	private Integer orderNo ;
	 	public Integer getOrderNo ()
	 	{
	 		return this.orderNo;
	 	}
	 	public void setOrderNo (Integer value)
	 	{
	 		this.orderNo	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 8.softkey
	 	 备注:
		*/
	 	@ApiModelProperty(value = "softkey")
	 	private String softKey ;
	 	public String getSoftKey ()
	 	{
	 		return this.softKey;
	 	}
	 	public void setSoftKey (String value)
	 	{
	 		this.softKey	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 9.创建时间
	 	 备注:
		*/
	 	@ApiModelProperty(value = "创建时间")
	 	private Date createDate ;
	 	public Date getCreateDate ()
	 	{
	 		return this.createDate;
	 	}
	 	public void setCreateDate (Date value)
	 	{
	 		this.createDate	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 10.适配设备
	 	 备注:
		*/
	 	@ApiModelProperty(value = "适配设备")
	 	private String deviceOS ;
	 	public String getDeviceOS ()
	 	{
	 		return this.deviceOS;
	 	}
	 	public void setDeviceOS (String value)
	 	{
	 		this.deviceOS	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	public void setSession(Map map) {
		// TODO Auto-generated method stub
	}
}
 
 
 
 

 
		 

 


