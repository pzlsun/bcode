package publicresourcewrite.code.pojo;
import java.util.Date;
import java.util.Map;
import java.util.List;
import java.util.UUID;
import baselib.baseclass.BasePojo;
//增加字段注释

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.wordnik.swagger.annotations.ApiModelProperty;
///////////////////////////////////////////////////////////
// ObjectID : CF739993-6812-44B5-B91E-1E1970E583EB
//医生履历
//

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class DoctorExperience  extends BasePojo implements java.io.Serializable {
  
    @ApiModelProperty(value = "主键列表（公共字段）")
    private List<Object> keylist;
		
	 
	 	public List<Object> getKeylist() {
			return keylist;
		}
		public void setKeylist(List<Object> keylist) {
			this.keylist = keylist;
		}
    
    
	protected static final long serialVersionUID = -1153530269037757832l;
	 	/*
		 0.ID
	 	 备注:
		*/
	 	@ApiModelProperty(value = "ID")
	 	private Integer iD ;
	 	public Integer getID ()
	 	{
	 		return this.iD;
	 	}
	 	public void setID (Integer value)
	 	{
	 		this.iD	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 1.医生ID
	 	 备注:
		*/
	 	@ApiModelProperty(value = "医生ID")
	 	private Integer doctorID ;
	 	public Integer getDoctorID ()
	 	{
	 		return this.doctorID;
	 	}
	 	public void setDoctorID (Integer value)
	 	{
	 		this.doctorID	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 2.医院(医学院)
	 	 备注:
		*/
	 	@ApiModelProperty(value = "医院(医学院)")
	 	private String hospital ;
	 	public String getHospital ()
	 	{
	 		return this.hospital;
	 	}
	 	public void setHospital (String value)
	 	{
	 		this.hospital	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 3.职称
	 	 备注:
		*/
	 	@ApiModelProperty(value = "职称")
	 	private String title ;
	 	public String getTitle ()
	 	{
	 		return this.title;
	 	}
	 	public void setTitle (String value)
	 	{
	 		this.title	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 4.成绩
	 	 备注:
		*/
	 	@ApiModelProperty(value = "成绩")
	 	private Integer score ;
	 	public Integer getScore ()
	 	{
	 		return this.score;
	 	}
	 	public void setScore (Integer value)
	 	{
	 		this.score	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 5.经历
	 	 备注:
		*/
	 	@ApiModelProperty(value = "经历")
	 	private String resume ;
	 	public String getResume ()
	 	{
	 		return this.resume;
	 	}
	 	public void setResume (String value)
	 	{
	 		this.resume	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 6.时间
	 	 备注:
		*/
	 	@ApiModelProperty(value = "时间")
	 	private String occurrenceTime ;
	 	public String getOccurrenceTime ()
	 	{
	 		return this.occurrenceTime;
	 	}
	 	public void setOccurrenceTime (String value)
	 	{
	 		this.occurrenceTime	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 7.履历类型(职业,学业)
	 	 备注:
		*/
	 	@ApiModelProperty(value = "履历类型(职业,学业)")
	 	private String resumeType ;
	 	public String getResumeType ()
	 	{
	 		return this.resumeType;
	 	}
	 	public void setResumeType (String value)
	 	{
	 		this.resumeType	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	public void setSession(Map map) {
		// TODO Auto-generated method stub
	}
}
 
 
 
 

 
		 

 


