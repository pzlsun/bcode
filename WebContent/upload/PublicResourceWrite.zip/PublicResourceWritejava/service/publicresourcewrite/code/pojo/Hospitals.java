package publicresourcewrite.code.pojo;
import java.util.Date;
import java.util.Map;
import java.util.List;
import java.util.UUID;
import baselib.baseclass.BasePojo;
//增加字段注释

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.wordnik.swagger.annotations.ApiModelProperty;
///////////////////////////////////////////////////////////
// ObjectID : CC7E00C8-E97A-4619-9AE8-09446381C6E6
//医院
//

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class Hospitals  extends BasePojo implements java.io.Serializable {
  
    @ApiModelProperty(value = "主键列表（公共字段）")
    private List<Object> keylist;
		
	 
	 	public List<Object> getKeylist() {
			return keylist;
		}
		public void setKeylist(List<Object> keylist) {
			this.keylist = keylist;
		}
    
    
	protected static final long serialVersionUID = 2229145779409680700l;
	 	/*
		 0.ID
	 	 备注:
		*/
	 	@ApiModelProperty(value = "ID")
	 	private Integer iD ;
	 	public Integer getID ()
	 	{
	 		return this.iD;
	 	}
	 	public void setID (Integer value)
	 	{
	 		this.iD	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 1.医院名称
	 	 备注:
		*/
	 	@ApiModelProperty(value = "医院名称")
	 	private String hospitalName ;
	 	public String getHospitalName ()
	 	{
	 		return this.hospitalName;
	 	}
	 	public void setHospitalName (String value)
	 	{
	 		this.hospitalName	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 2.医院信息
	 	 备注:
		*/
	 	@ApiModelProperty(value = "医院信息")
	 	private String hospitalInfomation ;
	 	public String getHospitalInfomation ()
	 	{
	 		return this.hospitalInfomation;
	 	}
	 	public void setHospitalInfomation (String value)
	 	{
	 		this.hospitalInfomation	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 3.医院简介
	 	 备注:
		*/
	 	@ApiModelProperty(value = "医院简介")
	 	private String description ;
	 	public String getDescription ()
	 	{
	 		return this.description;
	 	}
	 	public void setDescription (String value)
	 	{
	 		this.description	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 4.等级
	 	 备注:
		*/
	 	@ApiModelProperty(value = "等级")
	 	private String level ;
	 	public String getLevel ()
	 	{
	 		return this.level;
	 	}
	 	public void setLevel (String value)
	 	{
	 		this.level	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 5.城市
	 	 备注:
		*/
	 	@ApiModelProperty(value = "城市")
	 	private String city ;
	 	public String getCity ()
	 	{
	 		return this.city;
	 	}
	 	public void setCity (String value)
	 	{
	 		this.city	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 6.纬度
	 	 备注:
		*/
	 	@ApiModelProperty(value = "纬度")
	 	private String longitude ;
	 	public String getLongitude ()
	 	{
	 		return this.longitude;
	 	}
	 	public void setLongitude (String value)
	 	{
	 		this.longitude	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 7.经度
	 	 备注:
		*/
	 	@ApiModelProperty(value = "经度")
	 	private String latitude ;
	 	public String getLatitude ()
	 	{
	 		return this.latitude;
	 	}
	 	public void setLatitude (String value)
	 	{
	 		this.latitude	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 8.通信地址
	 	 备注:
		*/
	 	@ApiModelProperty(value = "通信地址")
	 	private String address ;
	 	public String getAddress ()
	 	{
	 		return this.address;
	 	}
	 	public void setAddress (String value)
	 	{
	 		this.address	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 9.邮编
	 	 备注:
		*/
	 	@ApiModelProperty(value = "邮编")
	 	private String postCode ;
	 	public String getPostCode ()
	 	{
	 		return this.postCode;
	 	}
	 	public void setPostCode (String value)
	 	{
	 		this.postCode	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 10.TrafficRoute
	 	 备注:
		*/
	 	@ApiModelProperty(value = "TrafficRoute")
	 	private String trafficRoute ;
	 	public String getTrafficRoute ()
	 	{
	 		return this.trafficRoute;
	 	}
	 	public void setTrafficRoute (String value)
	 	{
	 		this.trafficRoute	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 11.类型
	 	 备注:
		*/
	 	@ApiModelProperty(value = "类型")
	 	private String type ;
	 	public String getType ()
	 	{
	 		return this.type;
	 	}
	 	public void setType (String value)
	 	{
	 		this.type	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 12.VisitNum
	 	 备注:
		*/
	 	@ApiModelProperty(value = "VisitNum")
	 	private String visitNum ;
	 	public String getVisitNum ()
	 	{
	 		return this.visitNum;
	 	}
	 	public void setVisitNum (String value)
	 	{
	 		this.visitNum	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 13.电话
	 	 备注:
		*/
	 	@ApiModelProperty(value = "电话")
	 	private String telePhone ;
	 	public String getTelePhone ()
	 	{
	 		return this.telePhone;
	 	}
	 	public void setTelePhone (String value)
	 	{
	 		this.telePhone	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 14.ImportanceMediacalSpeciality
	 	 备注:
		*/
	 	@ApiModelProperty(value = "ImportanceMediacalSpeciality")
	 	private String importanceMediacalSpeciality ;
	 	public String getImportanceMediacalSpeciality ()
	 	{
	 		return this.importanceMediacalSpeciality;
	 	}
	 	public void setImportanceMediacalSpeciality (String value)
	 	{
	 		this.importanceMediacalSpeciality	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 15.AllMediacalSpeciality
	 	 备注:
		*/
	 	@ApiModelProperty(value = "AllMediacalSpeciality")
	 	private String allMediacalSpeciality ;
	 	public String getAllMediacalSpeciality ()
	 	{
	 		return this.allMediacalSpeciality;
	 	}
	 	public void setAllMediacalSpeciality (String value)
	 	{
	 		this.allMediacalSpeciality	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 16.病床数量
	 	 备注:
		*/
	 	@ApiModelProperty(value = "病床数量")
	 	private String bedNum ;
	 	public String getBedNum ()
	 	{
	 		return this.bedNum;
	 	}
	 	public void setBedNum (String value)
	 	{
	 		this.bedNum	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 17.邮箱
	 	 备注:
		*/
	 	@ApiModelProperty(value = "邮箱")
	 	private String email ;
	 	public String getEmail ()
	 	{
	 		return this.email;
	 	}
	 	public void setEmail (String value)
	 	{
	 		this.email	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 18.省份
	 	 备注:
		*/
	 	@ApiModelProperty(value = "省份")
	 	private String province ;
	 	public String getProvince ()
	 	{
	 		return this.province;
	 	}
	 	public void setProvince (String value)
	 	{
	 		this.province	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 19.国家
	 	 备注:
		*/
	 	@ApiModelProperty(value = "国家")
	 	private String country ;
	 	public String getCountry ()
	 	{
	 		return this.country;
	 	}
	 	public void setCountry (String value)
	 	{
	 		this.country	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 20.别名
	 	 备注:
		*/
	 	@ApiModelProperty(value = "别名")
	 	private String otherHospitalName ;
	 	public String getOtherHospitalName ()
	 	{
	 		return this.otherHospitalName;
	 	}
	 	public void setOtherHospitalName (String value)
	 	{
	 		this.otherHospitalName	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 21.HeadWordForName
	 	 备注:
		*/
	 	@ApiModelProperty(value = "HeadWordForName")
	 	private String headWordForName ;
	 	public String getHeadWordForName ()
	 	{
	 		return this.headWordForName;
	 	}
	 	public void setHeadWordForName (String value)
	 	{
	 		this.headWordForName	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 22.院长姓名
	 	 备注:
		*/
	 	@ApiModelProperty(value = "院长姓名")
	 	private String yuanzhang ;
	 	public String getYuanzhang ()
	 	{
	 		return this.yuanzhang;
	 	}
	 	public void setYuanzhang (String value)
	 	{
	 		this.yuanzhang	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 23.省份id
	 	 备注:
		*/
	 	@ApiModelProperty(value = "省份id")
	 	private Integer provinceId ;
	 	public Integer getProvinceId ()
	 	{
	 		return this.provinceId;
	 	}
	 	public void setProvinceId (Integer value)
	 	{
	 		this.provinceId	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 24.城市id
	 	 备注:
		*/
	 	@ApiModelProperty(value = "城市id")
	 	private Integer cityId ;
	 	public Integer getCityId ()
	 	{
	 		return this.cityId;
	 	}
	 	public void setCityId (Integer value)
	 	{
	 		this.cityId	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 25.录入者
	 	 备注:
		*/
	 	@ApiModelProperty(value = "录入者")
	 	private Integer creator ;
	 	public Integer getCreator ()
	 	{
	 		return this.creator;
	 	}
	 	public void setCreator (Integer value)
	 	{
	 		this.creator	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 26.录入时间
	 	 备注:
		*/
	 	@ApiModelProperty(value = "录入时间")
	 	private Date createDate ;
	 	public Date getCreateDate ()
	 	{
	 		return this.createDate;
	 	}
	 	public void setCreateDate (Date value)
	 	{
	 		this.createDate	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 27.标签
	 	 备注:
		*/
	 	@ApiModelProperty(value = "标签")
	 	private String tag ;
	 	public String getTag ()
	 	{
	 		return this.tag;
	 	}
	 	public void setTag (String value)
	 	{
	 		this.tag	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 28.状态
	 	 备注:
		*/
	 	@ApiModelProperty(value = "状态")
	 	private Integer status ;
	 	public Integer getStatus ()
	 	{
	 		return this.status;
	 	}
	 	public void setStatus (Integer value)
	 	{
	 		this.status	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 29.医院key
	 	 备注:
		*/
	 	@ApiModelProperty(value = "医院key")
	 	private String hospitalKey ;
	 	public String getHospitalKey ()
	 	{
	 		return this.hospitalKey;
	 	}
	 	public void setHospitalKey (String value)
	 	{
	 		this.hospitalKey	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 30.网址
	 	 备注:
		*/
	 	@ApiModelProperty(value = "网址")
	 	private String url ;
	 	public String getUrl ()
	 	{
	 		return this.url;
	 	}
	 	public void setUrl (String value)
	 	{
	 		this.url	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 31.医院logo地址
	 	 备注:
		*/
	 	@ApiModelProperty(value = "医院logo地址")
	 	private String logoUrl ;
	 	public String getLogoUrl ()
	 	{
	 		return this.logoUrl;
	 	}
	 	public void setLogoUrl (String value)
	 	{
	 		this.logoUrl	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	public void setSession(Map map) {
		// TODO Auto-generated method stub
	}
}
 
 
 
 

 
		 

 


