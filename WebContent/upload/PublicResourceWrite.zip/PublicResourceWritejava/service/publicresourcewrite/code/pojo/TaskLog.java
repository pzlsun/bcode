package publicresourcewrite.code.pojo;
import java.util.Date;
import java.util.Map;
import java.util.List;
import java.util.UUID;
import baselib.baseclass.BasePojo;
//增加字段注释

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.wordnik.swagger.annotations.ApiModelProperty;
///////////////////////////////////////////////////////////
// ObjectID : D2EC4029-B742-47CB-AE52-065E363F5DF2
//任务完成日志
//

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class TaskLog  extends BasePojo implements java.io.Serializable {
  
    @ApiModelProperty(value = "主键列表（公共字段）")
    private List<Object> keylist;
		
	 
	 	public List<Object> getKeylist() {
			return keylist;
		}
		public void setKeylist(List<Object> keylist) {
			this.keylist = keylist;
		}
    
    
	protected static final long serialVersionUID = -2526846096427040986l;
	 	/*
		 0.ID
	 	 备注:
		*/
	 	@ApiModelProperty(value = "ID")
	 	private Integer iD ;
	 	public Integer getID ()
	 	{
	 		return this.iD;
	 	}
	 	public void setID (Integer value)
	 	{
	 		this.iD	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 1.任务ID
	 	 备注:
		*/
	 	@ApiModelProperty(value = "任务ID")
	 	private Integer taskID ;
	 	public Integer getTaskID ()
	 	{
	 		return this.taskID;
	 	}
	 	public void setTaskID (Integer value)
	 	{
	 		this.taskID	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 2.用户ID
	 	 备注:
		*/
	 	@ApiModelProperty(value = "用户ID")
	 	private Integer 用户ID ;
	 	public Integer get用户ID ()
	 	{
	 		return this.用户ID;
	 	}
	 	public void set用户ID (Integer value)
	 	{
	 		this.用户ID	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 3.完成结果
	 	 备注:
		*/
	 	@ApiModelProperty(value = "完成结果")
	 	private String result ;
	 	public String getResult ()
	 	{
	 		return this.result;
	 	}
	 	public void setResult (String value)
	 	{
	 		this.result	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 4.完成时间
	 	 备注:
		*/
	 	@ApiModelProperty(value = "完成时间")
	 	private Date createTime ;
	 	public Date getCreateTime ()
	 	{
	 		return this.createTime;
	 	}
	 	public void setCreateTime (Date value)
	 	{
	 		this.createTime	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	public void setSession(Map map) {
		// TODO Auto-generated method stub
	}
}
 
 
 
 

 
		 

 


