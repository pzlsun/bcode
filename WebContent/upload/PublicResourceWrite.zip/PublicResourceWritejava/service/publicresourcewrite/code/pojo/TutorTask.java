package publicresourcewrite.code.pojo;
import java.util.Date;
import java.util.Map;
import java.util.List;
import java.util.UUID;
import baselib.baseclass.BasePojo;
//增加字段注释

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.wordnik.swagger.annotations.ApiModelProperty;
///////////////////////////////////////////////////////////
// ObjectID : 832C87D3-7A46-4191-BFA1-0EAF5130A600
//导师任务
//资料，活动，问卷

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class TutorTask  extends BasePojo implements java.io.Serializable {
  
    @ApiModelProperty(value = "主键列表（公共字段）")
    private List<Object> keylist;
		
	 
	 	public List<Object> getKeylist() {
			return keylist;
		}
		public void setKeylist(List<Object> keylist) {
			this.keylist = keylist;
		}
    
    
	protected static final long serialVersionUID = -7552021753030744025l;
	 	/*
		 0.ID
	 	 备注:
		*/
	 	@ApiModelProperty(value = "ID")
	 	private Integer iD ;
	 	public Integer getID ()
	 	{
	 		return this.iD;
	 	}
	 	public void setID (Integer value)
	 	{
	 		this.iD	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 1.导师ID
	 	 备注:
		*/
	 	@ApiModelProperty(value = "导师ID")
	 	private Integer tutorID ;
	 	public Integer getTutorID ()
	 	{
	 		return this.tutorID;
	 	}
	 	public void setTutorID (Integer value)
	 	{
	 		this.tutorID	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 2.项类型（问卷，随访)
	 	 备注:
		*/
	 	@ApiModelProperty(value = "项类型（问卷，随访)")
	 	private String itemType ;
	 	public String getItemType ()
	 	{
	 		return this.itemType;
	 	}
	 	public void setItemType (String value)
	 	{
	 		this.itemType	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 3.项ID
	 	 备注:
		*/
	 	@ApiModelProperty(value = "项ID")
	 	private Integer itemID ;
	 	public Integer getItemID ()
	 	{
	 		return this.itemID;
	 	}
	 	public void setItemID (Integer value)
	 	{
	 		this.itemID	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 4.标题
	 	 备注:
		*/
	 	@ApiModelProperty(value = "标题")
	 	private String title ;
	 	public String getTitle ()
	 	{
	 		return this.title;
	 	}
	 	public void setTitle (String value)
	 	{
	 		this.title	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 5.任务简介
	 	 备注:
		*/
	 	@ApiModelProperty(value = "任务简介")
	 	private String taskSummary ;
	 	public String getTaskSummary ()
	 	{
	 		return this.taskSummary;
	 	}
	 	public void setTaskSummary (String value)
	 	{
	 		this.taskSummary	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 6.缩略图
	 	 备注:
		*/
	 	@ApiModelProperty(value = "缩略图")
	 	private String thumImg ;
	 	public String getThumImg ()
	 	{
	 		return this.thumImg;
	 	}
	 	public void setThumImg (String value)
	 	{
	 		this.thumImg	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 7.发布时间
	 	 备注:
		*/
	 	@ApiModelProperty(value = "发布时间")
	 	private Date pubTime ;
	 	public Date getPubTime ()
	 	{
	 		return this.pubTime;
	 	}
	 	public void setPubTime (Date value)
	 	{
	 		this.pubTime	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 8.任务类型
	 	 备注:
		*/
	 	@ApiModelProperty(value = "任务类型")
	 	private String taskType ;
	 	public String getTaskType ()
	 	{
	 		return this.taskType;
	 	}
	 	public void setTaskType (String value)
	 	{
	 		this.taskType	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 9.状态
	 	 备注:
		*/
	 	@ApiModelProperty(value = "状态")
	 	private Integer status ;
	 	public Integer getStatus ()
	 	{
	 		return this.status;
	 	}
	 	public void setStatus (Integer value)
	 	{
	 		this.status	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	 	/*
		 10.浏览量
	 	 备注:
		*/
	 	@ApiModelProperty(value = "浏览量")
	 	private Integer viewNum ;
	 	public Integer getViewNum ()
	 	{
	 		return this.viewNum;
	 	}
	 	public void setViewNum (Integer value)
	 	{
	 		this.viewNum	=	value;
	 		if(value!=null)
			this.isAllPropNull=false;
	 	}		 
	public void setSession(Map map) {
		// TODO Auto-generated method stub
	}
}
 
 
 
 

 
		 

 


